package test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Kerninator;

public class KerninatorTests {

  @DisplayName("no spaces between letters")
  @Test
  public void no_spaces_between_letters() {
    Kerninator kerny = new Kerninator(0);
    assertThat(kerny.kerninate("bar")).isEqualTo("bar");
  }

  @DisplayName("one space between letters")
  @Test
  public void one_space_between_letters() {
    Kerninator kerny = new Kerninator(1);
    assertThat(kerny.kerninate("foo")).isEqualTo("f o o");
  }

  @DisplayName("case changes to lowercase")
  @Test
  public void case_changes_to_lowercase() {
    Kerninator kerny = new Kerninator(5);
    assertThat(kerny.kerninate("WAt")).isEqualTo("w     a     t");
  }
}
