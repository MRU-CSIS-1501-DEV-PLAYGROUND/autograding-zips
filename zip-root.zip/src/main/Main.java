package main;

// TODO
// import anything you need

public class Main {

  /**
   * We can use our main as a convenient place to play with our code...to see it in action.
   *
   * @param args
   */
  public static void main(String[] args) {
    // TODO
    // use a Scanner to get keyboard input

    // TODO
    // prompt for a command from the user

    // TODO
    // store the command from the user in a variable
    String command = ""; // this isn't correct...you need to fix it

    String theWord = wordFromCommand(command);
    int numSpaces = numSpacesFromCommand(command);

    // TODO
    // make a Kerninator object that uses the number of spaces from the command

    System.out.println(); // throw this in their to space things up nicely

    // TODO
    // display expected output

  }

  /**
   * Returns the word to be kerninated in a kernination command of the form: word|num spaces|.
   *
   * <p>Examples:
   *
   * <ul>
   *   <li>wordFromCommand("spy|12|") => "spy"
   *   <li>wordFromCommand("YES|0|") => "YES"
   * </ul>
   *
   * @param command a command in the given form
   * @return the word in word|num spaces|
   */
  private static String wordFromCommand(String command) {
    // TODO
    // complete this method so that it does what it says it will
  }

  /**
   * Returns the number of spaces to kerninate in a kernination command of the form word|num
   * spaces|.
   *
   * <p>Examples:
   *
   * <ul>
   *   <li>numSpacesFromCommand("spy|12|") => 12
   *   <li>numSpacesFromCommand("YES|0|") => 0
   * </ul>
   *
   * @param command a command in the given form
   * @return the number of spaces in word|num spaces|
   */
  private static int numSpacesFromCommand(String command) {
    // TODO
    // complete this method so that it does what it says it will
  }
}
