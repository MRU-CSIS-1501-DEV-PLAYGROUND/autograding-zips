package main;

public class Kerninator {

  // TODO
  // instance variables go here....which ones do you need?

  /**
   * Creates a Kerninator that puts a given number of spaces between every letter of text it is
   * asked to kerninate.
   *
   * <p>ASSUMPTION: the number of spaces is >= 0
   *
   * @param numSpacesBetweenLetters the number of spaces between letters
   */
  public Kerninator(int numSpacesBetweenLetters) {
    // TODO
    // initialize any instance variables you've decided to use
  }

  /**
   * Returns a copy of the given three-letter text with the number of spaces this Kerninator was set
   * up to use. All letters in this copy are lowercase.
   *
   * <p>ASSUMPTION: the text provided is exactly 3 characters long
   *
   * <p>Examples for a 2-space Kerninator:
   *
   * <ul>
   *   <li>kerninate("yo.") => "y o !"
   *   <li>kerninate("BOO") => "b o o"
   *   <li>kerninate("L0l") => "l 0 l"
   * </ul>
   *
   * @param text the three-letter text to kerninate
   * @return the kerninated version of the given text
   */
  public String kerninate(String text) {
    // TODO
    // solve the kernination problem...I'd suggest using String.format
  }
}
