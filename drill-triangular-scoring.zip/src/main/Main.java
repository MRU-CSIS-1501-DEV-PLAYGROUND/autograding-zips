package main;

public class Main {

  /**
   * We can use our main as a convenient place to play with our code...to see it in action.
   *
   * @param args
   */
  public static void main(String[] args) {
    System.out.println(
        "Here are the Sushi Go dumpling scores for a game between Anh, Miko, and Olga:");
    System.out.println();

    // make a new TriangularScorer object with the
    // proper maximum score (based on what you've been told
    // about Sushi Go)

    int numDumplingsAnh = 2;
    int dumplingScoreAnh; // what value should this have?

    int numDumplingsMiko = 6;
    int dumplingScoreMiko; // what value should this have?

    int numDumplingsOlga = 5;
    int dumplingScoreOlga; // what value should this have?

    System.out.printf("%-7s%-12s%-8s%n", "Name", "Dumplings", "Score");
    // complete the table with printf...three more rows need to be done
  }
}
