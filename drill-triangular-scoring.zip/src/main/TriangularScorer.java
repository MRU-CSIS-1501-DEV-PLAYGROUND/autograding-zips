package main;

public class TriangularScorer {

  // instance variable probably should go here

  /**
   * Creates a TriangularScorer that uses the triangular number series
   * (https://www.mathsisfun.com/algebra/triangular-numbers.html to generate scores up to some
   * maximum allowable score.
   *
   * <p>Assumption: the maximum score allowed is >= 0
   *
   * @param maxScoreAllowed the maximum score allowed by this scorer
   */
  public TriangularScorer(int maxScoreAllowed) {
    // constructors initialize instance variables...better do that, eh?
  }

  /**
   * Returns the score for a given number of items.
   *
   * <p>Assumption: the given number of items to score is >= 0
   *
   * <p>Examples (assuming a max score of 14 allowed):
   *
   * <ul>
   *   <li>scoreFor(0) => 0
   *   <li>scoreFor(3) => 6
   *   <li>scoreFor(4) => 10
   *   <li>scoreFor(5) => 14
   *   <li>scoreFor(12) => 14
   *
   * @param numItemsScored the number of items to score
   * @return the score for the given number of items, up to the maximum score allowed
   */
  public int scoreFor(int numItemsScored) {
    // your code descends from the heavens and lands here
  }
}
