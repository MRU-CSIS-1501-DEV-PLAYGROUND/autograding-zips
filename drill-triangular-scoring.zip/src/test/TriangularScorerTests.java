﻿package test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.TriangularScorer;

public class TriangularScorerTests {

  @DisplayName("max score is 0")
  @Test
  public void scores_when_max_is_0() {
    TriangularScorer scorer = new TriangularScorer(0);

    assertThat(scorer.scoreFor(0)).isZero();
    assertThat(scorer.scoreFor(1)).isZero();
    assertThat(scorer.scoreFor(2)).isZero();
    assertThat(scorer.scoreFor(3)).isZero();
    assertThat(scorer.scoreFor(4)).isZero();
    assertThat(scorer.scoreFor(5)).isZero();
    assertThat(scorer.scoreFor(10)).isZero();
  }

  @DisplayName("max score is 4")
  @Test
  public void scores_when_max_is_4() {
    final int maxScore = 4;
    TriangularScorer scorer = new TriangularScorer(maxScore);

    assertThat(scorer.scoreFor(0)).isEqualTo(0);
    assertThat(scorer.scoreFor(1)).isEqualTo(1);
    assertThat(scorer.scoreFor(2)).isEqualTo(3);
    assertThat(scorer.scoreFor(3)).isEqualTo(maxScore);
    assertThat(scorer.scoreFor(4)).isEqualTo(maxScore);
    assertThat(scorer.scoreFor(5)).isEqualTo(maxScore);
    assertThat(scorer.scoreFor(10)).isEqualTo(maxScore);
  }

  @DisplayName("max score is 21")
  @Test
  public void scores_when_max_is_21() {
    final int maxScore = 21;
    TriangularScorer scorer = new TriangularScorer(maxScore);

    assertThat(scorer.scoreFor(0)).isEqualTo(0);
    assertThat(scorer.scoreFor(1)).isEqualTo(1);
    assertThat(scorer.scoreFor(2)).isEqualTo(3);
    assertThat(scorer.scoreFor(3)).isEqualTo(6);
    assertThat(scorer.scoreFor(4)).isEqualTo(10);
    assertThat(scorer.scoreFor(5)).isEqualTo(15);
    assertThat(scorer.scoreFor(10)).isEqualTo(maxScore);
  }
}
