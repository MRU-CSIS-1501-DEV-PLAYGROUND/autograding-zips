﻿package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.tapSystemOutNormalized;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Main;

public class MainTest {

  @Test
  @DisplayName("Expected statements should appear in the console.")
  public void console_displays_expected_text() throws Exception {

    String expectedOutput =
        String.join(
            "\n",
            "Here are the Sushi Go dumpling scores for a game between Anh, Miko, and Olga:",
            "",
            "Name   Dumplings   Score   ",
            "Anh    2           3       ",
            "Miko   6           15      ",
            "Olga   5           15"); // no trailing whitespace...because of
    // systemLambda

    String whatIsOutput = tapSystemOutNormalized(() -> Main.main(new String[0])).trim();

    assertThat(whatIsOutput).isEqualTo(expectedOutput);
  }
}
