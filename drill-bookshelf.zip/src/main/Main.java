package main;

// TODO
// imports? probably

public class Main {

  /**
   * We can use our main as a convenient place to play with our code...to see it in action.
   *
   * @param args the usual main args
   */
  public static void main(String[] args) {
    // TODO
    // we've got keyboard input to deal with, so....

    // TODO
    // prompt for and receive the shelf width

    // TODO
    // now that you've got the width of the shelf, make a Bookshelf!

    System.out.println("Let's place a book!");

    // TODO
    // prompt for book width and use it to place a book

    // TODO
    // output the current state of the shelf

    System.out.println("Let's place another book!");

    // TODO
    // prompt for book width and use it to place a book

    // TODO
    // output the current state of the shelf
  }
}
