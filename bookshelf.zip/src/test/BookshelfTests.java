package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Bookshelf;

public class BookshelfTests {


    @DisplayName("a new Bookshelf has no books on it")
    @Test
    public void new_bookshelf_has_no_books_on_it() {
      int someWidth = 17;
      Bookshelf shelf = new Bookshelf(someWidth);

      assertThat(shelf.numBooksPresent()).isEqualTo(0);
    }

    @DisplayName("a new bookshelf starts with empty space equal to its width")
    @Test
    public void new_bookshelf_starts_with_empty_space_equal_to_its_width() {
      int someWidth = 209;
      Bookshelf shelf = new Bookshelf(someWidth);

      assertThat(shelf.emptySpaceAvailable()).isEqualTo(someWidth);
    }


    @DisplayName("putting a book on that fits reduces free space")
    @Test
    public void putting_a_book_on_that_fits_reduces_free_space() {
      int someWidth = 100;
      Bookshelf shelf = new Bookshelf(someWidth);

      shelf.placeBookOfWidth(20);
      assertThat(shelf.emptySpaceAvailable()).isEqualTo(80);

  }
}
